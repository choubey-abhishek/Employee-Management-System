
package com.ems.service;

import org.springframework.stereotype.Service;
import com.ems.model.Salary;
import com.ems.repository.SalaryRepository;

@Service
public class SalaryService {
 private final SalaryRepository repo;

 public SalaryService(SalaryRepository repo) {
  this.repo = repo;
 }

 public Salary generate(Salary s) {
  s.setNetSalary(s.getBaseSalary() - s.getDeductions());
  return repo.save(s);
 }
}
