
package com.ems.service;

import org.springframework.stereotype.Service;
import com.ems.model.Attendance;
import com.ems.repository.AttendanceRepository;

@Service
public class AttendanceService {
 private final AttendanceRepository repo;

 public AttendanceService(AttendanceRepository repo) {
  this.repo = repo;
 }

 public Attendance save(Attendance a) {
  return repo.save(a);
 }
}
