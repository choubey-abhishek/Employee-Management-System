
package com.ems.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.ems.model.Employee;
import com.ems.repository.EmployeeRepository;

@Service
public class EmployeeService {
 private final EmployeeRepository repo;

 public EmployeeService(EmployeeRepository repo) {
  this.repo = repo;
 }

 public Employee save(Employee e) {
  return repo.save(e);
 }

 public List<Employee> findAll() {
  return repo.findAll();
 }
}
