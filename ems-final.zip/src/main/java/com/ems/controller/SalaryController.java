
package com.ems.controller;

import org.springframework.web.bind.annotation.*;
import com.ems.model.Salary;
import com.ems.service.SalaryService;

@RestController
@RequestMapping("/api/salary")
public class SalaryController {
 private final SalaryService service;

 public SalaryController(SalaryService service) {
  this.service = service;
 }

 @PostMapping
 public Salary generate(@RequestBody Salary s) {
  return service.generate(s);
 }
}
