
package com.ems.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;
import com.ems.model.Employee;
import com.ems.service.EmployeeService;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
 private final EmployeeService service;

 public EmployeeController(EmployeeService service) {
  this.service = service;
 }

 @PostMapping
 public Employee create(@RequestBody Employee e) {
  return service.save(e);
 }

 @GetMapping
 public List<Employee> all() {
  return service.findAll();
 }
}
