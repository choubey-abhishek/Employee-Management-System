
package com.ems.controller;

import org.springframework.web.bind.annotation.*;
import com.ems.model.Attendance;
import com.ems.service.AttendanceService;

@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {
 private final AttendanceService service;

 public AttendanceController(AttendanceService service) {
  this.service = service;
 }

 @PostMapping
 public Attendance mark(@RequestBody Attendance a) {
  return service.save(a);
 }
}
