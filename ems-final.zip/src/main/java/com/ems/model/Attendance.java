
package com.ems.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Attendance {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 @ManyToOne
 private Employee employee;

 private LocalDate date;
 private String status;

 public Long getId() { return id; }
 public void setId(Long id) { this.id = id; }
 public Employee getEmployee() { return employee; }
 public void setEmployee(Employee employee) { this.employee = employee; }
 public LocalDate getDate() { return date; }
 public void setDate(LocalDate date) { this.date = date; }
 public String getStatus() { return status; }
 public void setStatus(String status) { this.status = status; }
}
