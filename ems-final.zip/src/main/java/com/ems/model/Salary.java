
package com.ems.model;

import jakarta.persistence.*;

@Entity
public class Salary {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 @ManyToOne
 private Employee employee;

 private double baseSalary;
 private double deductions;
 private double netSalary;

 public Long getId() { return id; }
 public void setId(Long id) { this.id = id; }
 public Employee getEmployee() { return employee; }
 public void setEmployee(Employee employee) { this.employee = employee; }
 public double getBaseSalary() { return baseSalary; }
 public void setBaseSalary(double baseSalary) { this.baseSalary = baseSalary; }
 public double getDeductions() { return deductions; }
 public void setDeductions(double deductions) { this.deductions = deductions; }
 public double getNetSalary() { return netSalary; }
 public void setNetSalary(double netSalary) { this.netSalary = netSalary; }
}
