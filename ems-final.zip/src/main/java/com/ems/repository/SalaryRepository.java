
package com.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ems.model.Salary;

public interface SalaryRepository extends JpaRepository<Salary, Long> {}
